<template>
  <div>

  </div>
</template>

<script>

export default {
  name: "HomeComponent",
  components: {

  }
}
</script>

<style scoped>

</style>