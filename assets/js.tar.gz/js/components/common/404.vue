<template>
<div>
  <h1>404 - Not Found</h1>
</div>
</template>

<script>
export default {
name: "NotFound"
}
</script>

<style scoped>

</style>